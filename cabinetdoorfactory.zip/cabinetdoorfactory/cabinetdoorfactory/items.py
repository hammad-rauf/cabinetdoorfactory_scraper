# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class CabinetdoorfactoryItem(scrapy.Item):

    title = scrapy.Field()
    image = scrapy.Field()
    url = scrapy.Field()
    highprice = scrapy.Field()
    lowprice = scrapy.Field()
    currency = scrapy.Field()
    description = scrapy.Field()
    category = scrapy.Field()
    sub_category = scrapy.Field()

    skus = scrapy.Field()

    paintgradeoptions = scrapy.Field()

    finishingptions = scrapy.Field()


    pass
