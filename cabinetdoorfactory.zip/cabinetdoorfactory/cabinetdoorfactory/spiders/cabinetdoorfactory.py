from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import CabinetdoorfactoryItem

#from datetime import date


class CabinetDoorFactorySpider(CrawlSpider):

    name = "cabinetdoorfactory"

    img_link = "https://www.cabinetdoorfactory.com/"

    start_urls = [
                "https://www.cabinetdoorfactory.com/"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=(["#page-home .tree >li > a",".active ~ span:last-child a"]))),
        Rule(LinkExtractor(restrict_css=(".catalog-product  .catalog-product-image  a")),callback="cabinetdoorfactory"),  
    )

#per sq. ft.

    def cabinetdoorfactory(self, response):

        products = CabinetdoorfactoryItem()
        

        products["title"] = response.css(".product-title::text").extract_first()

        products["image"] = response.css(".product-image img::attr(src)").extract_first()
        products["image"] = self.img_link + products["image"]
        products["image"] = products["image"].replace("og","")

        products["url"] = response.url

        products["highprice"] = response.css("span[itemprop='highPrice']::text").extract_first()

        products["lowprice"] = response.css("span[itemprop='lowPrice']::text").extract_first()

        products["currency"] = response.css("span[itemprop='currency']::attr(content)").extract_first()
        
        products["description"] = response.css(".product-page-center.gap-top div[itemprop='description']::text").extract()

        products["category"] = response.css(".product-bread-crumbs a:nth-child(2)::text").extract_first()

        products["sub_category"] = response.css(".product-bread-crumbs a:nth-child(3)::text").extract_first()

        products["skus"] = []

        for specie in response.css(".product-wood-specie"):

            sku = {
                "image" : None,
                "title" : None,
                "price" : None
            }    

            skus = specie.css("li::text").extract()
            
            for i in range(0,len(skus)):
                skus[i] = skus[i].strip('\n')

            skus = list(filter(None, skus))

            images = specie.css("li img::attr(src)").extract_first()

            images = self.img_link + images

            sku["title"] = skus[0]
            sku["price"] = skus[1]
            sku["image"] = images

            products["skus"].append(sku)


        products["paintgradeoptions"] = response.css("tr[id='tr-paint-grade-options'] option::text").extract()

        for i in range(0,len(products["paintgradeoptions"])):
             products["paintgradeoptions"][i] = products["paintgradeoptions"][i].strip('\n')

        products["finishingptions"] = response.css("tr[id='tr-finishing-options'] option::text").extract()

        for i in range(0,len(products["finishingptions"])):
             products["finishingptions"][i] = products["finishingptions"][i].strip('\n')


        yield products
 